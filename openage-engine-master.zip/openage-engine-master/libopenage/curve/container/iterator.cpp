// Copyright 2017-2025 the openage authors. See copying.md for legal info.

#include "iterator.h"

namespace openage::curve {

// This file is intended to be empty

} // namespace openage::curve
